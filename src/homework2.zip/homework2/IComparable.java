package homework2;

public interface IComparable {
    public int compareTo(Object comparable);
    public boolean equal(Object comparable);
}

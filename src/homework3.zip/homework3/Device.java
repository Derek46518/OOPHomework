package homework3;

/**
 * This interface is used to be interact with devices, such as TV and Light
 */
public interface Device {
    /**
     * the execution method
     */
    void execute();
}
